Einstieg in die Website ueber Index.html

Gruppenmitglieder:

	N.Jost, L.Kalb, W.Siegert